<?php

namespace Clerk\Clerk\Block\Adminhtml\Insights;

use Clerk\Clerk\Block\Adminhtml\Dashboard;

class Audience extends Dashboard
{
    protected $type = 'audience';
}