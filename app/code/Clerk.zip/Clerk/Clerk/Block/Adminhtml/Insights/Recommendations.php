<?php

namespace Clerk\Clerk\Block\Adminhtml\Insights;

use Clerk\Clerk\Block\Adminhtml\Dashboard;

class Recommendations extends Dashboard
{
    protected $type = 'recommendations';
}