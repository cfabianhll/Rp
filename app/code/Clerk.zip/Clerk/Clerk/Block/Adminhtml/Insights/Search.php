<?php

namespace Clerk\Clerk\Block\Adminhtml\Insights;

use Clerk\Clerk\Block\Adminhtml\Dashboard;

class Search extends Dashboard
{
    protected $type = 'search';
}