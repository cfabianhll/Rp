<?php

namespace Clerk\Clerk\Block\Adminhtml\Insights;

use Clerk\Clerk\Block\Adminhtml\Dashboard;

class Email extends Dashboard
{
    protected $type = 'email';
}